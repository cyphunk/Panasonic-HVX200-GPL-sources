/*====================================================================*/

/* Panasonic P2 Card config result of parse_configfile()  */

/* DCM_MOD_ID:025 2004.10.04 Y.Takano */

static struct adjust_list_t p2_root_adjust_09 = {
	{/*adjust_t*/
		(u_int) 1, /* u_int Action */
		(u_int) 3, /* u_int Resource */
		(u_int) 0, /* u_int Attributes */
		{ /*union resource*/
			{ /*irq*/
				(u_long) 7, /* u_int IRQ (=memory u_long Base) */
				(u_long) 0  /* dummy     (=memory u_long Size) */
			}
		},
	},
	NULL       /* next */
};

static struct adjust_list_t p2_root_adjust_08 = {
	{/*adjust_t*/
		(u_int) 1, /* u_int Action */
		(u_int) 3, /* u_int Resource */
		(u_int) 0, /* u_int Attributes */
		{ /*union resource*/
			{ /*irq*/
				(u_long) 4, /* u_int IRQ (=memory u_long Base) */
				(u_long) 0  /* dummy     (=memory u_long Size) */
			}
		},
	},
	&p2_root_adjust_09  /* next */
};

static struct adjust_list_t p2_root_adjust_07 = {
	{/*adjust_t*/
		(u_int) 2, /* u_int Action */
		(u_int) 2, /* u_int Resource */
		(u_int) 0, /* u_int Attributes */
		{ /*union resource*/
			{ /*io*/
				(u_long) 0x04000100, /* ioaddr_t(=u_short) {NumPorts,BasePort} */
				(u_long)          0  /* u_int IOAddrLines (=memory u_long Size)*/
			}
		},
	},
	&p2_root_adjust_08  /* next */
};

static struct adjust_list_t p2_root_adjust_06 = {
	{/*adjust_t*/
		(u_int) 2, /* u_int Action */
		(u_int) 2, /* u_int Resource */
		(u_int) 0, /* u_int Attributes */
		{ /*union resource*/
			{ /*io*/
				(u_long) 0x01000c00, /* ioaddr_t(=u_short) {NumPorts,BasePort} */
				(u_long)          0  /* u_int IOAddrLines (=memory u_long Size)*/
			}
		},
	},
	&p2_root_adjust_07  /* next */
};


static struct adjust_list_t p2_root_adjust_05 = {
	{/*adjust_t*/
		(u_int) 2, /* u_int Action */
		(u_int) 1, /* u_int Resource */
		(u_int) 0, /* u_int Attributes */
		{ /*union resource*/
			{ /*memory*/
				(u_long) 0xfd090000, /* Base */
				(u_long) 0x00010000  /* Size */
			}
		},
	},
	&p2_root_adjust_06  /* next */
};

static struct adjust_list_t p2_root_adjust_04 = {
	{/*adjust_t*/
		(u_int) 2, /* u_int Action */
		(u_int) 1, /* u_int Resource */
		(u_int) 0, /* u_int Attributes */
		{ /*union resource*/
			{ /*memory*/
				(u_long) 0xfd080000, /* Base */
				(u_long) 0x00010000  /* Size */
			}
		},
	},
	&p2_root_adjust_05  /* next */
};

static struct adjust_list_t p2_root_adjust_03 = {
	{/*adjust_t*/
		(u_int) 2, /* u_int Action */
		(u_int) 1, /* u_int Resource */
		(u_int) 0, /* u_int Attributes */
		{ /*union resource*/
			{ /*memory*/
				(u_long) 0xfd070000, /* Base */
				(u_long) 0x00010000  /* Size */
			}
		},
	},
	&p2_root_adjust_04  /* next */
};

static struct adjust_list_t p2_root_adjust_02 = {
	{/*adjust_t*/
		(u_int) 2, /* u_int Action */
		(u_int) 1, /* u_int Resource */
		(u_int) 0, /* u_int Attributes */
		{ /*union resource*/
			{ /*memory*/
				(u_long) 0xfd060000, /* Base */
				(u_long) 0x00010000/* Size */
			}
		},
	},
	&p2_root_adjust_03  /* next */
};

static struct adjust_list_t p2_root_adjust_01 = {
	{/*adjust_t*/
		(u_int) 2, /* u_int Action */
		(u_int) 1, /* u_int Resource */
		(u_int) 0, /* u_int Attributes */
		{ /*union resource*/
			{ /*memory*/
				(u_long) 0xfd050000, /* Base */
				(u_long) 0x00010000/* Size */
			}
		},
	},
	&p2_root_adjust_02  /* next */
};

static struct adjust_list_t p2_root_adjust_00 = {
	{/*adjust_t*/
		(u_int) 2, /* u_int Action */
		(u_int) 1, /* u_int Resource */
		(u_int) 0, /* u_int Attributes */
		{ /*union resource*/
			{ /*memory*/
				(u_long) 0x000c0000, /* Base */
				(u_long) 0x00040000/* Size */
			}
		},
	},
	&p2_root_adjust_01  /* next */
};

/*====================================================================*/

static struct device_info_t p2_root_device_01 = {
	"spd",      /* char dev_info_t[DEV_NAME_LEN] */
	0,          /* int needs_mtd */
	2,          /* int modules */
	{           /* char *module[MAX_MODULES] */
		"cb_enabler",
		"spd",
		NULL,
		NULL
	},
	{           /* char *opts[MAX_MODULES] */
		NULL,
		NULL,
		NULL,
		NULL
	},
	"spd",      /* char *class */
	1,          /* int refs */
	NULL        /* struct device_info_t *next */
};

static struct device_info_t p2_root_device_00 = {
	"proxy",    /* char dev_info_t[DEV_NAME_LEN] */
	0,          /* int needs_mtd */
	1,          /* int modules */
	{           /* char *module[MAX_MODULES] */
		"proxy",
		NULL,
		NULL,
		NULL
	},
	{           /* char *opts[MAX_MODULES] */
		NULL,
		NULL,
		NULL,
		NULL
	},
	NULL,              /* char *class */
	1,                 /* int refs */
	&p2_root_device_01 /* struct device_info_t *next */
};
	    
/*====================================================================*/

static struct card_info_t p2_root_card_01 = {
	"Panasonic P2 Card", /* char *name */
	128,                 /* int ident_type */
	{
		{                /* vers_ident_t vers */
			0,           /* int ns */
			{            /* char *pi[4] */
				NULL,
				NULL,
				NULL,
				NULL
			}
		}
	},
	{                    /* manfid_ident_t manfid */
		(u_short) 0x10f7,/* u_short manf */
		(u_short) 0x8206 /* u_short card */
	},
	1,                   /* int bindings */
	{                    /* device_info_t *device[MAX_BINDINGS] */
		&p2_root_device_01,
		NULL,
		NULL,
		NULL
	},
	{                    /* int dev_fn[MAX_BINDINGS] */
		0,
		0,
		0,
		0
	},
	{                    /* char *class[MAX_BINDINGS] */
		NULL,
		NULL,
		NULL,
		NULL
	},
	NULL,                /* char *cis_file */
	1,                   /* int refs */
	NULL                 /* struct card_info_t *next */
};

static struct card_info_t p2_root_card_00 = {
	"Panasonic Proxy Card", /* char *name */
	0x0002,                 /* int ident_type */
	{
		{                /* vers_ident_t vers */
			0,           /* int ns */
			{            /* char *pi[4] */
				NULL,
				NULL,
				NULL,
				NULL
			}
		}
	},
	{                    /* manfid_ident_t manfid */
		(u_short) 0x0032,/* u_short manf */
		(u_short) 0x000d /* u_short card */
	},
	1,                   /* int bindings */
	{                    /* device_info_t *device[MAX_BINDINGS] */
		&p2_root_device_00,
		NULL,
		NULL,
		NULL
	},
	{                    /* int dev_fn[MAX_BINDINGS] */
		0,
		0,
		0,
		0
	},
	{                    /* char *class[MAX_BINDINGS] */
		NULL,
		NULL,
		NULL,
		NULL
	},
	NULL,                /* char *cis_file */
	1,                   /* int refs */
	&p2_root_card_01     /* struct card_info_t *next */
};

/*====================================================================*/

/* for debug function to get result of parse_configfile() */
/*====================================================================*/

