/* DCM_MOD_ID:002 2004.10.04 Y.Takano */

#undef PDEBUG
#ifdef DUMMY_CARDMGR_DEBUG
#  define PDEBUG(fmt, args...) \
     printk("<1>[%s] %s: " fmt, __FILE__, __func__, ## args)
#else
#  define PDEBUG(fmt, args...) /* not debbuging: nothing */
#endif /* DUMMY_CARDMGR_DEBUG */

#undef PDEBUGG
#define PDEBUGG(fmt, args...) /* nothing: it's a placeholder */

#undef PERROR
#ifdef DUMMY_CARDMGR_ERROR
#  define PERROR(fmt, args...) \
     printk(KERN_WARNING "[%s] %s: ERROR!: " fmt, __FILE__, __func__, ## args)
#else
#  define PERROR(fmt, args...) /* nothing: it's a placeholder */
#endif /* DUMMY_CARDMGR_ERROR */


#undef IR
#ifdef DEBUG_EVENT
#  define IR(n) \
do { \
  volatile unsigned char *addr = (volatile unsigned char *)0xba000000; \
  static int i = 0, r = 0; \
  if ((n)) { \
    if (!i) { \
      PDEBUG("======== INSERTION ========\n"); \
      *addr |= 0x80; \
      i++; \
    } \
  } else { \
    if (!r) { \
      PDEBUG("======== REMOVAL ========\n"); \
      *addr &= ~0x80; \
      r++; \
    } \
  } \
} while (0)
#else
#  define IR(n)
#endif /* DEBUG_EVENT */

