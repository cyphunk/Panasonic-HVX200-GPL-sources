/* DCM_MOD_ID:001 2004.10.04 Y.Takano */

#ifdef DUMMY_CARDMGR

#include <linux/tqueue.h>
#include <linux/interrupt.h>


static adjust_t dcm_adjust_res[] = {
  { ADD_MANAGED_RESOURCE, RES_MEMORY_RANGE, 0, { { 0x000c0000, 0x40000 } } },
  { ADD_MANAGED_RESOURCE, RES_MEMORY_RANGE, 0, { { 0xfd050000, 0x10000 } } },
  { ADD_MANAGED_RESOURCE, RES_MEMORY_RANGE, 0, { { 0xfd060000, 0x10000 } } },
  { ADD_MANAGED_RESOURCE, RES_MEMORY_RANGE, 0, { { 0xfd070000, 0x10000 } } },
  { ADD_MANAGED_RESOURCE, RES_MEMORY_RANGE, 0, { { 0xfd080000, 0x10000 } } },
  { ADD_MANAGED_RESOURCE, RES_MEMORY_RANGE, 0, { { 0xfd090000, 0x10000 } } },
  { ADD_MANAGED_RESOURCE, RES_IO_RANGE,     0, { { 0x01000c00, 0       } } },
  { ADD_MANAGED_RESOURCE, RES_IO_RANGE,     0, { { 0x04000100, 0       } } },
  { REMOVE_MANAGED_RESOURCE, RES_IRQ,       0, { { 0x00000004, 0       } } },
  { REMOVE_MANAGED_RESOURCE, RES_IRQ,       0, { { 0x00000007, 0       } } }
};
#define MAX_ADJUSTINGS (sizeof(dcm_adjust_res) / sizeof(adjust_t))


#define MAX_BINDINGS 4
typedef struct dummy_cardmgr_card_info {
  u_short manf;
  u_short card;
  char *dev_info[MAX_BINDINGS];
} dummy_cardmgr_card_info_t;

typedef struct dummy_cardmgr_sock_info {
  int detect_status;
  bind_info_t *bind[MAX_BINDINGS];
  spinlock_t sock_lock;
} dummy_cardmgr_sock_info_t;


static dummy_cardmgr_card_info_t dcm_proxy_info = {
  0x0032, 0x000d, { "proxy", NULL, NULL, NULL }
};

static dummy_cardmgr_card_info_t *detect_cards[] = {
  &dcm_proxy_info
};
#define MAX_DETECTS \
(sizeof(detect_cards) / sizeof(dummy_cardmgr_card_info_t *))

static dummy_cardmgr_sock_info_t dcm_sock_info[] = {
  { 0, { NULL, }, SPIN_LOCK_UNLOCKED },
  { 0, { NULL, }, SPIN_LOCK_UNLOCKED },
  { 0, { NULL, }, SPIN_LOCK_UNLOCKED },
  { 0, { NULL, }, SPIN_LOCK_UNLOCKED },
  { 0, { NULL, }, SPIN_LOCK_UNLOCKED },
  { 0, { NULL, }, SPIN_LOCK_UNLOCKED }
};
#define MAX_SOCKETS (sizeof(dcm_sock_info) / sizeof(dummy_cardmgr_sock_info_t))

extern int proxy_init(void);

static int (*init_modules[])(void) = { proxy_init };
#define MAX_INIT_MODULES (sizeof(init_modules) / sizeof(int))


static void ds_dummy_cardmgr_init(void);
static void ds_dummy_cardmgr_insertion(socket_t ns);
static void ds_dummy_cardmgr_removal(socket_t ns);

static struct tq_struct dcm_bind_task[MAX_SOCKETS];
static struct tq_struct dcm_unbind_task[MAX_SOCKETS];

static u_char dcm_status_flag;
#define DCM_FIRST_DETECTION (1 << 0)
#define DCM_STATE_ENABLED   (1 << 1)
#define DCM_ADJUSTED_RES    (1 << 2)
static spinlock_t dcm_status_flag_lock = SPIN_LOCK_UNLOCKED;


#endif /* DUMMY_CARDMGR */

