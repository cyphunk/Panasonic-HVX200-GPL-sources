#ifndef _PCMCIA_CONFIG_H
#define _PCMCIA_CONFIG_H

#define AUTOCONF_INCLUDED
#define __IN_PCMCIA_PACKAGE__

#include <pcmcia/autoconf.h>

#endif /* _PCMCIA_CONFIG_H */
