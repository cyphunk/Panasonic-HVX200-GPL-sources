#ifndef _COMPAT_KCOMP_H
#define _COMPAT_KCOMP_H

/* this is just for the ieee1394 drivers on 2.2 kernels */

#include <linux/list.h>
#include <linux/sched.h>
#include <linux/netdevice.h>
#include <linux/pagemap.h>
#define __exit

#endif /* _COMPAT_KCOMP_H */
