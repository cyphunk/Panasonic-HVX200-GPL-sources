extern int kill_init(int sig);
extern int bb_shutdown_system(unsigned long magic);

