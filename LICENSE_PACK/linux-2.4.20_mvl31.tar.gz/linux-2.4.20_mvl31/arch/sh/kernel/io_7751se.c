/* 
 * linux/arch/sh/kernel/io_7751se.c
 *
 * Copyright (C) 2001  Ian da Silva, Jeremy Siegel
 * Based largely on io_se.c.
 *
 * I/O routine for Hitachi 7751 SolutionEngine.
 *
 * Initial version only to support LAN access; some
 * placeholder code from io_se.c left in with the
 * expectation of later SuperIO and PCMCIA access.
 */

#include <linux/kernel.h>
#include <linux/types.h>
#include <asm/io.h>
#include <asm/hitachi_7751se.h>
#include <asm/addrspace.h>

#include <linux/pci.h>
#include <asm/pci-sh7751.h>

#if 0
/******************************************************************
 * Variables from io_se.c, related to PCMCIA (not PCI); we're not
 * compiling them in, and have removed references from functions
 * which follow.  [Many checked for IO ports in the range bounded
 * by sh_pcic_io_start/stop, and used sh_pcic_io_wbase as offset.
 * As start/stop are uninitialized, only port 0x0 would match?]
 * When used, remember to adjust names to avoid clash with io_se?
 *****************************************************************/
/* SH pcmcia io window base, start and end.  */
int sh_pcic_io_wbase = 0xb8400000;
int sh_pcic_io_start;
int sh_pcic_io_stop;
int sh_pcic_io_type;
int sh_pcic_io_dummy;
/*************************************************************/
#endif

/*
 * The 7751 Solution Engine uses the built-in PCI controller (PCIC)
 * of the 7751 processor, and has a SuperIO accessible via the PCI.
 * The board also includes a PCMCIA controller on its memory bus,
 * like the other Solution Engine boards.
 */ 

#define PCIIOBR		PCI_REG(SH7751_PCIIOBR)
#define PCIMBR          PCI_REG(SH7751_PCIMBR)
#define PCI_IO_AREA	SH7751_PCI_IO_BASE
#define PCI_MEM_AREA	SH7751_PCI_CONFIG_BASE

#define PCI_IOMAP(adr)	(PCI_IO_AREA + (adr & ~SH7751_PCIIOBR_MASK))

  /* Modified 2005/08/30 by Panasonic */
#define maybebadio(name,port) \
  printk( KERN_ERR "bad PC-like io %s for port 0x%lx at 0x%08x\n", \
		 #name, (port), (__u32) __builtin_return_address(0))

static inline void delay(void)
{
	ctrl_inw(0xa0000000);
}

#if 0
static inline volatile __u16 *
port2adr(unsigned int port)
{
	if (port >= 0x2000)
		return (volatile __u16 *) (PA_MRSHPC + (port - 0x2000));
	else
		return (volatile __u16 *) (PA_SUPERIO + (port << 1));
	maybebadio(port2adr, (unsigned long)port);
	return (volatile __u16*)port;
}
#endif

#if 0
/* The 7751 Solution Engine seems to have everything hooked */
/* up pretty normally (nothing on high-bytes only...) so this */
/* shouldn't be needed */
static inline int
shifted_port(unsigned long port)
{
	/* For IDE registers, value is not shifted */
	if ((0x1f0 <= port && port < 0x1f8) || port == 0x3f6)
		return 0;
	else
		return 1;
}
#endif
#if 0
/* In case someone configures the kernel w/o PCI support: in that */
/* scenario, don't ever bother to check for PCI-window addresses */

/* NOTE: WINDOW CHECK MAY BE A BIT OFF, HIGH PCIBIOS_MIN_IO WRAPS? */
#if defined(CONFIG_PCI)
#define CHECK_SH7751_PCIIO(port) \
  ((port >= PCIBIOS_MIN_IO) && (port < (PCIBIOS_MIN_IO + SH7751_PCI_IO_SIZE)))
#else
#define CHECK_SH7751_PCIIO(port) (0)
#endif
#endif

/*
 * General outline: remap really low stuff [eventually] to SuperIO,
 * stuff in PCI IO space (at or above window at pci.h:PCIBIOS_MIN_IO)
 * is mapped through the PCI IO window.  Stuff with high bits (PXSEG)
 * should be way beyond the window, and is used  w/o translation for
 * compatibility.
 */
unsigned char sh7751se_inb(unsigned long port)
{
#if defined(CONFIG_CF_ENABLER)
        if ((0x1f0 <= port && port < 0x1f8) || port == 0x3f6)
                return *(__u8 *)(PA_MRSHPC_IO + port + 0x40000);
#endif

        if (PXSEG(port))
                return *(volatile unsigned char *)port;
        else {
                ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR);
                return *((__u8 *)PCI_IOMAP(port));
        }
}

unsigned char sh7751se_inb_p(unsigned long port)
{
	unsigned char v;

#if defined(CONFIG_CF_ENABLER)
        if ((0x1f0 <= port && port < 0x1f8) || port == 0x3f6)
                v = *(__u8 *)(PA_MRSHPC_IO + port + 0x40000);
        else
#endif
        {
                if (PXSEG(port))
                        v = *(volatile unsigned char *)port;
                else {
                        ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR);
                        v = *((__u8 *)PCI_IOMAP(port));
		}
        }
        delay();
        return v;
}

unsigned short sh7751se_inw(unsigned long port)
{
#if defined(CONFIG_CF_ENABLER)
        if ((0x1f0 <= port && port < 0x1f8) || port == 0x3f6)
                return *(__u16 *)(PA_MRSHPC_IO + port);
#endif
        if (PXSEG(port))
                return *(volatile unsigned short *)port;
        else {
                ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR);
                return *((__u16 *)PCI_IOMAP(port));
	}
}

unsigned int sh7751se_inl(unsigned long port)
{
        if (PXSEG(port))
                return *(volatile unsigned long *)port;
	else {
		ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR);
		return *((__u32 *)PCI_IOMAP(port));
	}
}

void sh7751se_outb(unsigned char value, unsigned long port)
{
#if defined(CONFIG_CF_ENABLER)
        if ((0x1f0 <= port && port < 0x1f8) || port == 0x3f6)
                *(__u8 *)(PA_MRSHPC_IO + port + 0x40000) = value;
        else
#endif
        {
        	if (PXSEG(port))
                	*(volatile unsigned char *)port = value;
		else {
			ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR); 
        		*((__u8 *)PCI_IOMAP(port)) = value;
		}
	}
}

void sh7751se_outb_p(unsigned char value, unsigned long port)
{
#if defined(CONFIG_CF_ENABLER)
        if ((0x1f0 <= port && port < 0x1f8) || port == 0x3f6)
                *(__u8 *)(PA_MRSHPC_IO + port + 0x40000) = value;
        else
#endif
        {
        	if (PXSEG(port))
                	*(volatile unsigned char *)port = value;
		else {
			ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR); 
        		*((__u8*)PCI_IOMAP(port)) = value;
		}
	}
	delay();
}

void sh7751se_outw(unsigned short value, unsigned long port)
{
#if defined(CONFIG_CF_ENABLER)
        if ((0x1f0 <= port && port < 0x1f8) || port == 0x3f6)
                *(__u16 *)(PA_MRSHPC_IO + port) = value;
        else
#endif
        {
	       	if (PXSEG(port))
                	*(volatile unsigned short *)port = value;
		else {
			ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR);
        		*((__u16 *)PCI_IOMAP(port)) = value;
		}
	}
}

void sh7751se_outl(unsigned int value, unsigned long port)
{
        if (PXSEG(port))
                *(volatile unsigned long *)port = value;
	else {
		ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR);
        	*((__u32 *)PCI_IOMAP(port)) = value;
	}
}

void sh7751se_insb(unsigned long port, void *addr, unsigned long count)
{
        volatile __u8 *p = (__u8 *)PCI_IOMAP(port);
        ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR);
        while (count--) {
                *((__u8 *) addr)++ = *p;
	}
}

void sh7751se_insw(unsigned long port, void *addr, unsigned long count)
{
        volatile __u16 *p;

#if defined(CONFIG_CF_ENABLER)
        if (port==0x1f0)
                p = (__u16 *)(PA_MRSHPC_IO + port);
        else
#endif
        {
                p = (__u16 *)PCI_IOMAP(port);
                ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR);
        }

        while (count--) {
                *((__u16 *) addr)++ = *p;
	}
}

void sh7751se_insl(unsigned long port, void *addr, unsigned long count)
{
        volatile __u32 *p = (__u32 *)PCI_IOMAP(port);
        ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR);
        while (count--) {
                *((__u32 *) addr)++ = *p;
        }
}

void sh7751se_outsb(unsigned long port, const void *addr, unsigned long count)
{
        volatile __u8 *p = (__u8 *)PCI_IOMAP(port);
        ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR);
        while (count--){
                *p = *((__u8 *) addr)++;
        }
}

void sh7751se_outsw(unsigned long port, const void *addr, unsigned long count)
{
        volatile __u16 *p;

#if defined(CONFIG_CF_ENABLER)
        if (port==0x1f0)
                p = (__u16 *)(PA_MRSHPC_IO + port);
        else
#endif
        {
                p = (__u16 *)PCI_IOMAP(port);
                ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR);
        }

        while (count--) {
                *p = *((__u16 *) addr)++;
	}
}

void sh7751se_outsl(unsigned long port, const void *addr, unsigned long count)
{
        volatile __u32 *p = (__u32 *)PCI_IOMAP(port);
        ctrl_outl((port & SH7751_PCIIOBR_MASK), PCIIOBR);
        while (count--){
                *p = *((__u32 *) addr)++;
        }
}

/* For read/write calls, just copy generic (pass-thru); PCIMBR is  */
/* already set up.  For a larger memory space, these would need to */
/* reset PCIMBR as needed on a per-call basis...                   */

unsigned char sh7751se_readb(unsigned long addr)
{
        unsigned long phys_addr, pci_min_mem, pci_end_mem;

        phys_addr = PHYSADDR(addr);
        pci_min_mem = PHYSADDR(SH7751_PCI_MEMORY_BASE);
        pci_end_mem = PHYSADDR(SH7751_PCI_MEMORY_BASE) + SH7751_PCI_MEM_SIZE;

        if((phys_addr >= pci_min_mem) && (phys_addr < pci_end_mem)) {
                ctrl_outl((addr & 0xff000000), PCIMBR);
                return *((__u8 *)((addr & 0x00ffffff) + PCI_MEM_AREA));
        }
	return *(volatile unsigned char*)addr;
}

unsigned short sh7751se_readw(unsigned long addr)
{
        unsigned long phys_addr, pci_min_mem, pci_end_mem;

        phys_addr = PHYSADDR(addr);
        pci_min_mem = PHYSADDR(SH7751_PCI_MEMORY_BASE);
        pci_end_mem = PHYSADDR(SH7751_PCI_MEMORY_BASE) + SH7751_PCI_MEM_SIZE;

        if((phys_addr >= pci_min_mem) && (phys_addr < pci_end_mem)) {
                ctrl_outl((addr & 0xff000000), PCIMBR);
                return *((__u16 *)((addr & 0x00ffffff) + PCI_MEM_AREA));
        }
	return *(volatile unsigned short*)addr;
}

unsigned int sh7751se_readl(unsigned long addr)
{
        unsigned long phys_addr, pci_min_mem, pci_end_mem;

        phys_addr = PHYSADDR(addr);
        pci_min_mem = PHYSADDR(SH7751_PCI_MEMORY_BASE);
        pci_end_mem = PHYSADDR(SH7751_PCI_MEMORY_BASE) + SH7751_PCI_MEM_SIZE;

        if((phys_addr >= pci_min_mem) && (phys_addr < pci_end_mem)) {
                ctrl_outl((addr & 0xff000000), PCIMBR);
                return *((__u32 *)((addr & 0x00ffffff) + PCI_MEM_AREA));
        }
	return *(volatile unsigned long*)addr;
}

void sh7751se_writeb(unsigned char b, unsigned long addr)
{
        unsigned long phys_addr, pci_min_mem, pci_end_mem;

        phys_addr = PHYSADDR(addr);
        pci_min_mem = PHYSADDR(SH7751_PCI_MEMORY_BASE);
        pci_end_mem = PHYSADDR(SH7751_PCI_MEMORY_BASE) + SH7751_PCI_MEM_SIZE;

        if((phys_addr >= pci_min_mem) && (phys_addr < pci_end_mem)) {
                ctrl_outl((addr & 0xff000000), PCIMBR);
                addr = (addr & 0x00ffffff) + PCI_MEM_AREA;
        }
	*(volatile unsigned char*)addr = b;
}

void sh7751se_writew(unsigned short b, unsigned long addr)
{
        unsigned long phys_addr, pci_min_mem, pci_end_mem;

        phys_addr = PHYSADDR(addr);
        pci_min_mem = PHYSADDR(SH7751_PCI_MEMORY_BASE);
        pci_end_mem = PHYSADDR(SH7751_PCI_MEMORY_BASE) + SH7751_PCI_MEM_SIZE;

        if((phys_addr >= pci_min_mem) && (phys_addr < pci_end_mem)) {
                ctrl_outl((addr & 0xff000000), PCIMBR);
                addr = (addr & 0x00ffffff) + PCI_MEM_AREA;
        }
	*(volatile unsigned short*)addr = b;
}

void sh7751se_writel(unsigned int b, unsigned long addr)
{
        unsigned long phys_addr, pci_min_mem, pci_end_mem;

        phys_addr = PHYSADDR(addr);
        pci_min_mem = PHYSADDR(SH7751_PCI_MEMORY_BASE);
        pci_end_mem = PHYSADDR(SH7751_PCI_MEMORY_BASE) + SH7751_PCI_MEM_SIZE;

        if((phys_addr >= pci_min_mem) && (phys_addr < pci_end_mem)) {
                ctrl_outl((addr & 0xff000000), PCIMBR);
                addr = (addr & 0x00ffffff) + PCI_MEM_AREA;
        }
        *(volatile unsigned long*)addr = b;
}

void * se51_ioremap(unsigned long offset, unsigned long size)
{
        if(offset >= 0xfd000000)
                return (void *)offset;
        else
                return (void *)P2SEGADDR(offset);
}

void se51_iounmap(void *addr)
{
}

/* Map ISA bus address to the real address. Only for PCMCIA.  */

/* ISA page descriptor.  */
static __u32 sh_isa_memmap[256];

#if 0
static int
sh_isa_mmap(__u32 start, __u32 length, __u32 offset)
{
	int idx;

	if (start >= 0x100000 || (start & 0xfff) || (length != 0x1000))
		return -1;

	idx = start >> 12;
	sh_isa_memmap[idx] = 0xb8000000 + (offset &~ 0xfff);
	printk("sh_isa_mmap: start %x len %x offset %x (idx %x paddr %x)\n",
	       start, length, offset, idx, sh_isa_memmap[idx]);
	return 0;
}
#endif

unsigned long
sh7751se_isa_port2addr(unsigned long offset)
{
	int idx;

	idx = (offset >> 12) & 0xff;
	offset &= 0xfff;
	return sh_isa_memmap[idx] + offset;
}
