/* 
 * linux/arch/sh/kernel/setup_7751se.c
 *
 * Copyright (C) 2000  Kazumoto Kojima
 *
 * Hitachi SolutionEngine Support.
 *
 * Modified for 7751 Solution Engine by
 * Ian da Silva and Jeremy Siegel, 2001.
 */

#include <linux/config.h>
#include <linux/init.h>
#include <linux/irq.h>

#include <linux/hdreg.h>
#include <linux/ide.h>
#include <asm/io.h>
#include <asm/hitachi_7751se.h>
#include <asm/m1543c.h>

extern void sh_rtc_reset( void ); /* add by Panasonic 2004/08/04 */


/*****************************************************************/
//	CAUTION!!                             Panasonic 2004-06-24
//
//      PCI Bus reset will be issued from pcibios_init_platform(),
//      so that any kind of settings for PCI device will be
//      ignored.
//
//      CAUTION!!                             Panasonic 2004-06-24
/*****************************************************************/

static unsigned char m_irq_mask = 0xfb;
static unsigned char s_irq_mask = 0xff;
volatile unsigned long irq_err_count;

static void disable_se51_irq(unsigned int irq)
{
        unsigned long flags;

        save_and_cli(flags);
        if( irq < 8) {
                m_irq_mask |= (1 << irq);
                outb(m_irq_mask,I8259_M_MR);
        } else {
                s_irq_mask |= (1 << (irq - 8));
                outb(s_irq_mask,I8259_S_MR);
        }
        restore_flags(flags);

}

static void enable_se51_irq(unsigned int irq)
{
        unsigned long flags;

        save_and_cli(flags);

        if( irq < 8) {
                m_irq_mask &= ~(1 << irq);
                outb(m_irq_mask,I8259_M_MR);
        } else {
                s_irq_mask &= ~(1 << (irq - 8));
                outb(s_irq_mask,I8259_S_MR);
        }
        restore_flags(flags);
}

static inline int se51_irq_real(unsigned int irq)
{
        int value;
        int irqmask;

        if ( irq < 8) {
                irqmask = 1<<irq;
                outb(0x0b,I8259_M_CR);          /* ISR register */
                value = inb(I8259_M_CR) & irqmask;
                outb(0x0a,I8259_M_CR);          /* back ro the IPR reg */
                return value;
        }
        irqmask = 1<<(irq - 8);
        outb(0x0b,I8259_S_CR);          /* ISR register */
        value = inb(I8259_S_CR) & irqmask;
        outb(0x0a,I8259_S_CR);          /* back ro the IPR reg */
        return value;
}

static void mask_and_ack_se51(unsigned int irq)
{
        unsigned long flags;

        save_and_cli(flags);

        if(irq < 8) {
                if(m_irq_mask & (1<<irq)){
                  if(!se51_irq_real(irq)){
                    irq_err_count++;
                    printk("spurious 8259A interrupt: IRQ %x\n",irq);
                   }
                } else {
                        m_irq_mask |= (1<<irq);
                }
                inb(I8259_M_MR);                /* DUMMY */
                outb(m_irq_mask,I8259_M_MR);    /* disable */
                outb(0x60+irq,I8259_M_CR);      /* EOI */

        } else {
                if(s_irq_mask & (1<<(irq - 8))){
                  if(!se51_irq_real(irq)){
                    irq_err_count++;
                    printk("spurious 8259A interrupt: IRQ %x\n",irq);
                  }
                } else {
                        s_irq_mask |= (1<<(irq - 8));
                }
                inb(I8259_S_MR);                /* DUMMY */
                outb(s_irq_mask,I8259_S_MR);    /* disable */
                outb(0x60+(irq-8),I8259_S_CR);  /* EOI */
                outb(0x60+2,I8259_M_CR);
        }
        restore_flags(flags);
}

static void end_se51_irq(unsigned int irq)
{
        enable_se51_irq(irq);
}

static unsigned int startup_se51_irq(unsigned int irq)
{
        enable_se51_irq(irq);
        return 0;
}

static void shutdown_se51_irq(unsigned int irq)
{
        disable_se51_irq(irq);
}

static struct hw_interrupt_type se51_irq_type = {
        "MS7751SE-IRQ",
        startup_se51_irq,
        shutdown_se51_irq,
        enable_se51_irq,
        disable_se51_irq,
        mask_and_ack_se51,
        end_se51_irq
};

static void make_se51_irq(unsigned int irq)
{
        irq_desc[irq].handler = &se51_irq_type;
        irq_desc[irq].status  = IRQ_DISABLED;
        irq_desc[irq].action  = 0;
        irq_desc[irq].depth   = 1;
        disable_se51_irq(irq);
}

int se51_irq_demux(int irq)
{
        unsigned int poll;

        if( irq == 2 ) {
                outb(0x0c,I8259_M_CR);
                poll = inb(I8259_M_CR);
                if(poll & 0x80) {
                        irq = (poll & 0x07);
                }
                if( irq == 2) {
                        outb(0x0c,I8259_S_CR);
                        poll = inb(I8259_S_CR);
                        irq = (poll & 0x07) + 8;
                }
        }
        return irq;
}


/*
 * Initialize IRQ setting
 */
void __init init_7751se_IRQ(void)
{
#if 0
        make_ipr_irq(13, BCR_ILCRD, 3, 2);
#endif
        int i;
        *(unsigned short *)BCR_ILCRA = 0x0000;/* disable SLOT_IRQ8/7/6/5 */
        *(unsigned short *)BCR_ILCRB = 0x0000;/* disable SLOT_IRQ4/3/2/1 */
        *(unsigned short *)BCR_ILCRC = 0x0000;/* disable PCIRQ3/2/1/0 */
        *(unsigned short *)BCR_ILCRD = 0x0000;/* disable PCINTA/B/C/D */
        *(unsigned short *)BCR_ILCRE = 0x000d;/* enable M8259 INTR */

        outb(0x11, I8259_M_CR);         /* master icw1 edge trigger  */
        outb(0x11, I8259_S_CR);         /* slave icw1 edge trigger  */
        outb(0x20, I8259_M_MR);         /* m icw2 base vec 0x08     */
        outb(0x28, I8259_S_MR);         /* s icw2 base vec 0x70     */
        outb(0x04, I8259_M_MR);         /* m icw3 slave irq2        */
        outb(0x02, I8259_S_MR);         /* s icw3 slave id          */
        outb(0x01, I8259_M_MR);         /* m icw4 non buf normal eoi*/
        outb(0x01, I8259_S_MR);         /* s icw4 non buf normal eo1*/
        outb(0xfb, I8259_M_MR);         /* disable irq0--irq7  */
        outb(0xff, I8259_S_MR);         /* disable irq8--irq15 */

        for (i = 0; i < 16; i++){
                if(i == 2)
                        make_ipr_irq(2, BCR_ILCRA, 1, 0x0f - 2);
#if defined(CONFIG_CF_ENABLER)
                else if(i == 14)
                        make_ipr_irq(14,BCR_ILCRC, 0, 0x0f - 14);
#endif
#if 0
                else if(i == 9)
                        make_ipr_irq(9, BCR_ILCRD, 2, 0x0f - 9);
#endif
                else
                        make_se51_irq(i);
        }

        /* Add additional calls to make_ipr_irq() as drivers are added
         * and tested.
         */
		/* add by Panasonic 2004/06/23 ------------> */
	make_ipr_irq( 7, BCR_ILCRD, 3, 0x0f -  7);	// INTA#
	make_ipr_irq( 8, BCR_ILCRD, 2, 0x0f -  8);	// INTB#
	make_ipr_irq( 9, BCR_ILCRD, 1, 0x0f -  9);	// INTC#
	make_ipr_irq(10, BCR_ILCRD, 0, 0x0f - 10);	// INTD#
	
	make_ipr_irq(11, BCR_ILCRC, 3, 0x0f - 11);	// INTA#?
	make_ipr_irq(12, BCR_ILCRC, 2, 0x0f - 12);	// INTB#?
	make_ipr_irq(13, BCR_ILCRC, 1, 0x0f - 13);	// INTC#?
	make_ipr_irq(14, BCR_ILCRC, 0, 0x0f - 14);	// INTD#?
	/* <------------ add by Panasonic 2004/06/23 */
}

static void init_led(void)  /* Panasonic Original */
{
	printk("...Init LED...\n");
#if (defined(CONFIG_P2PF_P2_RUFUS) && CONFIG_P2PF_HW_VERSION >= 1) || defined(CONFIG_P2PF_P2_ARIEL)
	(*(volatile unsigned char*)PA_EVALED) &= ~(0x08);  /* heartbeat uses bit 3(LED4) */
	
#else /* (!CONFIG_P2PF_P2_RUFUS || CONFIG_P2PF_HW_VERSION < 1) && CONFIG_P2PF_P2_ARIEL */
	(*(volatile unsigned char*)PA_LED) &= ~(0x60);  /* heartbeat uses bit 5 and 6 */

#endif /* (CONFIG_P2PF_P2_RUFUS && CONFIG_P2PF_HW_VERSION >= 1) || CONFIG_P2PF_P2_ARIEL */
	
	(*(volatile unsigned char*)(PA_LED+0x01)) = 0; /* SD card LED */
}

#ifdef CONFIG_FB_E1356
#define BCR2                  0xFF800004UL
#define WCR2                  0xFF80000cUL
#define BCR2_MASK             0x0030
#define WCR2_MASK             0x00000e00
#define BCR2_VALUE            0x0020
#define WCR2_VALUE            0x00000400

static void __init init_epson1356(void)
{
	writew((readw(BCR2)&~BCR2_MASK)|BCR2_VALUE, BCR2);
	writel((readl(WCR2)&~WCR2_MASK)|WCR2_VALUE, WCR2);
}
#endif

#define PCICONF1 PCI_REG(SH7751_PCICONF1)

/*
 * Initialize the board
 */
void __init setup_7751se(void)
{
	/* Must be able to drive PCI bus -- force Bus Master bit on */
/* 	ctrl_outl( (ctrl_inl(PCICONF1)|SH7751_PCICONF1_BUM), PCICONF1 ); */

	init_led(); /* add by Panasonic 2004/06/23 */
#ifdef CONFIG_FB_E1356
	init_epson1356();
#endif
	/* XXX: RTC setting comes here */
	/* add by Panasonic 2004/08/04 */
	sh_rtc_reset();
}
