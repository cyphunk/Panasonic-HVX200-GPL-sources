/*
 * linux/arch/sh/kernel/pci-7751se.c
 *
 * Author:  Ian DaSilva (idasilva@mvista.com)
 *
 * Highly leveraged from pci-bigsur.c, written by Dustin McIntire.
 *
 * May be copied or modified under the terms of the GNU General Public
 * License.  See linux/COPYING for more information.
 *
 * PCI initialization for the Hitachi SH7751 Solution Engine board (MS7751SE01)
 */

#include <linux/config.h>
#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/pci.h>

#include <asm/io.h>
#include <asm/pci-sh7751.h>

#define PCIMCR_MRSET_OFF	0xBFFFFFFF
#define PCIMCR_RFSH_OFF		0xFFFFFFFB

#ifdef CONFIG_SPDMSC
# define PA_EXMNTR			0xB9800000 /* add 2004/06/23 by Panasonic */
#endif /* CONFIG_SPDMSC */

/*
 * Only long word accesses of the PCIC's internal local registers and the
 * configuration registers from the CPU is supported.
 */
#define PCIC_WRITE(x,v) writel((v), PCI_REG(x))
#define PCIC_READ(x) readl(PCI_REG(x))


/* Add 2005/07/20 by Panasonic ----> */
#ifdef CONFIG_PCMCIA_CS
static void init_panasonic_r5c812( void );
#endif /* CONFIG_PCMCIA_CS */
#ifdef CONFIG_SPDMSC
static int init_panasonic_msc( void );
#endif /* CONFIG_SPDMSC */
/* <---- Add 2005/07/20 by Panasonic */


/*
 * Description:  This function sets up and initializes the pcic, sets
 * up the BARS, maps the DRAM into the address space etc, etc.
 */
int __init pcibios_init_platform(void)
{
	/* modified 2004/06/23 by Panasonic ----> */
#ifdef CONFIG_SPDMSC
	int ret = -1;
	volatile unsigned char *msc_conf_done = (volatile unsigned char *)PA_EXMNTR;
#endif /* CONFIG_SPDMSC */
	/* <---- modified 2004/06/23 by Panasonic */
   unsigned long bcr1, wcr1, wcr2, wcr3, mcr;
   unsigned short bcr2, bcr3;
   
   /*
    * Initialize the slave bus controller on the pcic.  The values used
    * here should not be hardcoded, but they should be taken from the bsc
    * on the processor, to make this function as generic as possible.
    * (i.e. Another sbc may usr different SDRAM timing settings -- in order
    * for the pcic to work, its settings need to be exactly the same.)
    */
   bcr1 = (*(volatile unsigned long*)(SH7751_BCR1));
   bcr2 = (*(volatile unsigned short*)(SH7751_BCR2));
   bcr3 = (*(volatile unsigned short*)(SH7751_BCR3));
   wcr1 = (*(volatile unsigned long*)(SH7751_WCR1));
   wcr2 = (*(volatile unsigned long*)(SH7751_WCR2));
   wcr3 = (*(volatile unsigned long*)(SH7751_WCR3));
   mcr = (*(volatile unsigned long*)(SH7751_MCR));

   bcr1 = bcr1 | 0x00080000;  /* Enable Bit 19, BREQEN */
   (*(volatile unsigned long*)(SH7751_BCR1)) = bcr1;   

   bcr1 = bcr1 | 0x40080000;  /* Enable Bit 19 BREQEN, set PCIC to slave */
   PCIC_WRITE(SH7751_PCIBCR1, bcr1);	 /* PCIC BCR1 */
   PCIC_WRITE(SH7751_PCIBCR2, bcr2);     /* PCIC BCR2 */
   PCIC_WRITE(SH7751_PCIBCR3, bcr3);     /* PCIC BCR3 */
   PCIC_WRITE(SH7751_PCIWCR1, wcr1);     /* PCIC WCR1 */
   PCIC_WRITE(SH7751_PCIWCR2, wcr2);     /* PCIC WCR2 */
   PCIC_WRITE(SH7751_PCIWCR3, wcr3);     /* PCIC WCR3 */
   mcr = (mcr & PCIMCR_MRSET_OFF) & PCIMCR_RFSH_OFF;
   PCIC_WRITE(SH7751_PCIMCR, mcr);      /* PCIC MCR */
   
   /* Check MSC_CONF_DONE */
#ifdef CONFIG_SPDMSC
   /* modified 2004/06/23 by Panasonic ----> */
   if ( *msc_conf_done & 0x1 ) { /* check */
   	   printk( "MSC config done.\n" );
   } else {
	   mdelay(500); /* wait 500ms */
	   if ( !(*msc_conf_done & 0x1) ) {/* check */
		   printk( KERN_ERR "MSC config failed!!\n" );
		   while( 1 ) {;} /* sleep forever... */
	   }
   }
#endif /* CONFIG_SPDMSC */
   /* <---- modified 2004/06/23 by Panasonic */

   /* Asserting PCI bus Reset		*/
   /* Panasonic Modified 2004/06/23	*/
#if defined(CONFIG_P2PF_P2_ALICE)
   printk( "Asserting PCI bus Reset 16msec.\n" );
   PCIC_WRITE(SH7751_PCICR, 0xa5000002);	/* Set Reset Bit		*/
   mdelay(16);					/* Asserting Reset 16msec	*/
   PCIC_WRITE(SH7751_PCICR, 0xa5000000);	/* End of Reset			*/

#else
   printk( "PCI bus not Reset.\n" );
#endif
   
   /* Enable all interrupts, so we know what to fix */
   PCIC_WRITE(SH7751_PCIINTM, 0x0000c3ff);
   PCIC_WRITE(SH7751_PCIAINTM, 0x0000380f);

   /* Set up standard PCI config registers */
   PCIC_WRITE(SH7751_PCICONF1, 	0xFB900047); /* Bus Master, Mem & I/O access */
   PCIC_WRITE(SH7751_PCICONF2, 	0x00000000); /* PCI Class code & Revision ID */
   PCIC_WRITE(SH7751_PCICONF4, 	0xab000001); /* PCI I/O address (local regs) */
   PCIC_WRITE(SH7751_PCICONF5, 	CONFIG_MEMORY_START); /* PCI MEM address (local RAM) modified 2004/06/23 by Panasonic */
   PCIC_WRITE(SH7751_PCICONF6, 	0xd0000000); /* PCI MEM address (unused)     */
   PCIC_WRITE(SH7751_PCICONF11, 0x35051054); /* PCI Subsystem ID & Vendor ID */
   PCIC_WRITE(SH7751_PCILSR0, CONFIG_MEMORY_SIZE - 0x00100000);   /* MEM (full 64M exposed)       */
   PCIC_WRITE(SH7751_PCILSR1, 0x00000000);   /* MEM (unused)                 */
   PCIC_WRITE(SH7751_PCILAR0, CONFIG_MEMORY_START);   /* MEM (direct map from PCI)    */
   PCIC_WRITE(SH7751_PCILAR1, 0x00000000);   /* MEM (unused)                 */

   /* Now turn it on... */
   PCIC_WRITE(SH7751_PCICR, 0xa5000001);

   /*
    * Set PCIMBR and PCIIOBR here, assuming a single window
    * (16M MEM, 256K IO) is enough.  If a larger space is
    * needed, the readx/writex and inx/outx functions will
    * have to do more (e.g. setting registers for each call).
    */

   /*
    * Set the MBR so PCI address is one-to-one with window,
    * meaning all calls go straight through... use ifdef to
    * catch erroneous assumption.
    */
#if PCIBIOS_MIN_MEM != SH7751_PCI_MEMORY_BASE
#error One-to-one assumption for PCI memory mapping is wrong!?!?!?
#endif   
   PCIC_WRITE(SH7751_PCIMBR, PCIBIOS_MIN_MEM);

   /* Set IOBR for window containing area specified in pci.h */
   PCIC_WRITE(SH7751_PCIIOBR, (PCIBIOS_MIN_IO & SH7751_PCIIOBR_MASK));

   /* All done, may as well say so... */
   printk("SH7751 PCI: Finished initialization of the PCI controller\n");

/* Panasonic : Add initial setup function for Ricoh R5C812 & MSC 2006-06-24	*/
#ifdef CONFIG_PCMCIA_CS
   init_panasonic_r5c812( );
#endif /* CONFIG_PCMCIA_CS */
   
#ifdef CONFIG_SPDMSC
   ret = init_panasonic_msc( );
   if ( ret < 0 ) {
	   printk( KERN_ERR "SH7751 PCI: Error was occured during ZV port settings\n");
   }
   
#endif /* CONFIG_SPDMSC */
/* Panasonic : Add initial setup function for Ricoh R5C812 & MSC 2006-06-24	*/
   
   return 1;
}

int __init pcibios_map_platform_irq(u8 slot, u8 pin)
{
/*****************
  IRQ 0:
  IRQ 1:
  IRQ 2:
  IRQ 3:
  IRQ 4:
  IRQ 5:
  IRQ 6:
  IRQ 7: PCI_INTA
  IRQ 8: PCI_INIB
  IRQ 9: PCI_INTC
  IRQ10: PCI_INTD
  IRQ11:
  IRQ12:
  IRQ13:
  IRQ14:
  IRQ15:
*****************/
	printk("pcibios_map_platform_irq: slot=%d pin=%d\n", slot, pin);
	if (slot >= 16) return -1;

#if defined(CONFIG_P2PF_P2_ALICE)
	if(pin == 1){
		int irq_a[] = {
			-1, 7,  8,  9, 10, 10, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1
		};
		return irq_a[slot];
	}
	if(pin == 2){
		int irq_b[] = {
			-1, 8,  9, 10,  8, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1
		};
		return irq_b[slot];
	}
	if(pin == 3){
		int irq_c[] = {
			-1, 9, 10,  8,  9, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1
		};
		return irq_c[slot];
	}
	if(pin == 4){
		int irq_d[] = {
			-1, 10, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1
		};
		return irq_d[slot];
	}
#elif defined(CONFIG_P2PF_P2_RUFUS) || defined(CONFIG_P2PF_P2_ARIEL)
	if(pin == 1){
		int irq_a[] = {
			-1, 7,  8,  9, 10, 10, 10, -1, -1, -1, -1, -1, -1, -1, -1, -1
		};
		return irq_a[slot];
	}
	if(pin == 2){
		int irq_b[] = {
			-1, 8,  9, 10,  8, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1
		};
		return irq_b[slot];
	}
	if(pin == 3){
		int irq_c[] = {
			-1, 9, 10,  8,  9, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1
		};
		return irq_c[slot];
	}
	if(pin == 4){
		int irq_d[] = {
			-1, 10, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1
		};
		return irq_d[slot];
	}
#else
# error "Unknown target!"
#endif /* CONFIG_P2PF_* */
	
	return -1;
}


/* Panasonic 2004-06-24						*/
/* Initialize  functions for Ricoh R5C812 & MSC setups		*/

#define PCIPAR PCI_REG(SH7751_PCIPAR)
#define PCIPDR PCI_REG(SH7751_PCIPDR)

#if defined(CONFIG_PCMCIA_CS) || defined(CONFIG_SPDMSC)
static void __init pci_write_config(unsigned long busNo,
									unsigned long devNo,
									unsigned long fncNo,
									unsigned long cnfAdd,
									unsigned long cnfData)
{
	ctrl_outl((0x80000000
			   + ((busNo & 0xff)<<16)
			   + ((devNo & 0x1f)<<11)
			   + ((fncNo & 0x7)<<8)
			   + (cnfAdd & 0xfc)), PCIPAR);
	ctrl_outl(cnfData, PCIPDR);
}


static long __init pci_read_config(unsigned long busNo,
								   unsigned long devNo,
								   unsigned long fncNo,
								   unsigned long cnfAdd)
{
	ctrl_outl((0x80000000
			   + ((busNo & 0xff)<<16)
			   + ((devNo & 0x1f)<<11)
			   + ((fncNo & 0x7)<<8)
			   + (cnfAdd & 0xfc)), PCIPAR);
	return (ctrl_inl(PCIPDR));
}
#endif /* CONFIG_PCMCIA_CS || CONFIG_SPDMSC */

#ifdef CONFIG_PCMCIA_CS
static void init_panasonic_r5c812(void)
{
	unsigned long   lpc;
	unsigned long   val = 0L;
	
	/* Set ISA IRQ (output) pin --> GPIO (Hi-z) for #GBRST                  */
	/* UDIO1/2 of each Cardbus controller on R5C812         2004-06-08      */

	printk( "Set ISA IRQ (output) pin --> GPIO (Hi-z) for #GBRST\n" );
	
	for(lpc = 2 ; lpc < 5 ; lpc++){	/* Device No. 2 - 4 --> Ricoh R5C812	*/ 
		val = pci_read_config(0, lpc, 0, 0x00); /* Function No. 0 --> 5C476 CardBus Ctrl*/
		if(val == 0x04761180){
			if(lpc == 4){
				val = 0L;
				val = pci_read_config(0, lpc, 0, 0x80);
				val &= ~0x00800000; /* Clear SRIRQ Enable bit               */
				pci_write_config(0, lpc, 0, 0x80, val);
			}
			val = pci_read_config(0, lpc, 0, 0xA4);
			if(lpc == 4){
				val |= 0x00700776;  /* Set UDIO1 & UDIO2 as GPIO & ZV       */
			}else {
				val |= 0x00000770;  /* Set UDIO1 & UDIO2 as GPIO            */
			}
			pci_write_config(0, lpc, 0, 0xA4, val);
		}
/* Register 0x80 & 0xA4 are common register, so that we do not need following settings		*/
#if 0
		val = 0L;
		val = pci_read_config(0, lpc, 1, 0x00); 	/* Function No. 0 --> 5C476 CardBus Ctrl*/
		if(val == 0x04761180){
			if(lpc == 4){
				val = 0L;
				val = pci_read_config(0, lpc, 1, 0x80);
				val &= ~0x00800000;  /* Clear SRIRQ Enable bit               */
				pci_write_config(0, lpc, 1, 0x80, val);
			}
			val = 0L;
			val = pci_read_config(0, lpc, 1, 0xA4);
			if(lpc == 4){
				val |= 0x00700776;   /* Set UDIO1 & UDIO2 as GPIO & ZV       */
			}else {
				val |= 0x00000770;   /* Set UDIO1 & UDIO2 as GPIO            */
			}
			pci_write_config(0, lpc, 1, 0xA4, val);
		}
#endif
	}	
}
#endif /* CONFIG_PCMCIA_CS */

#ifdef CONFIG_SPDMSC
static int init_panasonic_msc(void)
{
	unsigned long   val = 0L;
	unsigned long 	temp;
	unsigned long	retry_count = 0L;

	printk( "Set MSC ZV port output register\n" );
		
	val = pci_read_config(0, 1, 0, 0x00); /* Check PCI device as Panasonic MSC	*/
	if(val != 0x820710f7){	/* Device No.1 = MSC			*/
		return -1;
	}
	
	/* Set ZV port output register		2005-03-23	*/
	/* Using in-direct memory space access			*/

	/* Read MISC register vis MBUS				*/
	val = pci_read_config(0, 1, 0, 0x54);
	if((val & 0x010000L) != 0x0L) {
		return -1;
	}
	
	val = (0x10000 * (0x000c & 0xFFFF)) & 0xFFFE0000L;
	pci_write_config(0, 1, 0, 0x54, val);
	val = 0x04L;
	pci_write_config(0, 1, 0, 0x50, val);
	do {
		val = pci_read_config(0, 1, 0, 0x54);
		if(retry_count > 10 ){
			return -1;
		}
		retry_count++;
	} while ((val & 0x010000L) != 0x0L);
	temp = (val & 0x0FFFFL);
	
	/* Write MISC register via MBUS to output ZV port signals*/
	val = pci_read_config(0, 1, 0, 0x54);
	if ((val & 0x010000L) != 0x0L) {
		return -1;
	}
	
	val = 0x10000 * (0x000c & 0xFFFF);
	val += temp | (0x00001 * (0x8000 & 0xFFFF));
	val &= 0xFFFEFFFFL;
	pci_write_config(0, 1, 0, 0x54, val);
	val = 0x03L;
	pci_write_config(0, 1, 0, 0x50, val);
	
	return 0;
}
#endif /* CONFIG_SPDMSC */

