/*
 * linux/arch/sh/kernel/led_se.c
 *
 * Copyright (C) 2000 Stuart Menefy <stuart.menefy@st.com>
 *
 * May be copied or modified under the terms of the GNU General Public
 * License.  See linux/COPYING for more information.
 *
 * This file contains Solution Engine specific LED code.
 */

#include <linux/config.h>

#ifdef CONFIG_SH_7751_SOLUTION_ENGINE
#include <asm/hitachi_7751se.h>
#elif defined(CONFIG_SH_MOBILE_SOLUTION_ENGINE)
#include <asm/hitachi_shmse.h>
#else
#include <asm/hitachi_se.h>
#endif

/* modified by Panasonic 2004/06/23 ------> */
#if 0
static void mach_led(int position, int value)
{
	volatile unsigned short* p = (volatile unsigned short*)PA_LED;

	if (value) {
		*p |= (1<<8);
	} else {
		*p &= ~(1<<8);
	}
}
#endif /* 0 */
/* <------ modified by Panasonic 2004/06/23 */

#ifdef CONFIG_HEARTBEAT

#include <linux/sched.h>

/* Cycle the LED's in the clasic Knightrider/Sun pattern */

/* Modified 2005/08/11, 2006/09/27 by Panasonic */
#if (defined(CONFIG_P2PF_P2_RUFUS) && CONFIG_P2PF_HW_VERSION >= 1) || defined(CONFIG_P2PF_P2_ARIEL)
void heartbeat_se(void)
{
	static unsigned int cnt = 0, period = 0;
	volatile unsigned char* p = (volatile unsigned char*)PA_EVALED;
	static unsigned bit = 3;
	static unsigned  up = 1;
	
	cnt += 1;
	if (cnt < period) {
		return;
	}

	cnt = 0;

	/* Go through the points (roughly!):
	 * f(0)=10, f(1)=16, f(2)=20, f(5)=35,f(inf)->110
	 */
	period = ( 110 - ( (300<<FSHIFT) / ((avenrun[0]/5) + (3<<FSHIFT)) ) ) * 4;
	*p &= ~(((unsigned char)1) << bit);
	if (up) {
			up=0;
			*p |= ((unsigned char)1) << (bit);
	} else {
			up=1;
	}

}

#else /* (!CONFIG_P2PF_P2_RUFUS || CONFIG_P2PF_HW_VERSION < 1) && !CONFIG_P2PF_P2_ARIEL */

void heartbeat_se(void)
{
	static unsigned int cnt = 0, period = 0;
/* modified by Panasonic 2004/06/24 --------> */
	volatile unsigned char* p = (volatile unsigned char*)PA_LED;
	static unsigned bit = 5;
	static unsigned  up = 1;
/* <-------- modified by Panasonic 2004/06/24 */
	
	cnt += 1;
	if (cnt < period) {
		return;
	}

	cnt = 0;

	/* Go through the points (roughly!):
	 * f(0)=10, f(1)=16, f(2)=20, f(5)=35,f(inf)->110
	 */

/* modified by Panasonic 2004/06/24 --------> */
/* 	period = 110 - ( (300<<FSHIFT)/ */
/* 			 ((avenrun[0]/5) + (3<<FSHIFT)) ); */
	period = ( 110 - ( (300<<FSHIFT) / ((avenrun[0]/5) + (3<<FSHIFT)) ) ) * 4;
/* <-------- modified by Panasonic 2004/06/24 */

	*p &= ~(((unsigned char)1) << bit); /* add by Panasonic 2004/06/24 */
	if (up) {
/* 		if (bit == 7) { */
		if (bit == 6) {
			bit--;
			up=0;
		} else {
			bit ++;
		}
	} else {
/* 		if (bit == 0) { */
		if (bit == 5) {
			bit++;
			up=1;
		} else {
			bit--;
		}
	}
/* 	*p = 1<<(bit+8); */
	*p |= ((unsigned char)1) << (bit); /* modified by Panasonic 2004/06/24 */
}
#endif /* (CONFIG_P2PF_P2_RUFUS && CONFIG_P2PF_HW_VERSION >= 1) || CONFIG_P2PF_P2_ARIEL */

#endif /* CONFIG_HEARTBEAT */
