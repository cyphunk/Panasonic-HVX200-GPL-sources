/*
	Copy Kernel Information & size of vmlinux bainary image
	for bootloader
					     Muraoka 2004-05-13
*/

#include <stdio.h>
#include <sys/stat.h>

#define	ADDR_XKERNEL_SIZE	0x480
#define	ADDR_BOOTINFO_SIZE	0x484
#define	ADDR_BOOTINFO		0x500

int main(void){
	
	struct stat stat_buf;
	FILE *f_info,*f_kernel;
	int	err;
	unsigned long lpc;
	unsigned long count = 0L;
	
	char *buf;
	char data;
	
	unsigned long kernel_size = 0L;
	unsigned long info_size = 0L;
	
	union {
		unsigned long l;
		unsigned char b[4];
	}convert;
	
	stat("vminfo",&stat_buf);
	info_size = (unsigned long)(stat_buf.st_size);
	
/* 	if(info_size > 512){ */
	if(info_size > 4096){
		printf("add_info: Error was occured at adding data in vmlinux image\n\n
			!!!!!!!!!! CAUTION ==> Build Failed !!!!!!!!!!!!!!!!!!!!!!!\n");
	}
	
	stat("vmlinux.bin",&stat_buf);
	kernel_size = (unsigned long)(stat_buf.st_size);

	printf( "kernelsize: %ld\n", kernel_size );
	
/*         if(info_size > 0x200000L){ */
	if(kernel_size > 0x200000L){
		printf("add_info: Binary image size of vmlinux exceeds 2MB\n
			Refer MTD partition map at KERNELROOT/drivers/mtd/maps/mymtd.c\n\n
			!!!!!!!!!!!!! CAUTION ==> Build Failed !!!!!!!!!!!!!!!!!!!!!!!\n");
	}
	
	f_info = fopen("vminfo", "rb");
	f_kernel = fopen("vmlinux.bin", "r+b");

	/*  Refer to BootLoader/bootloader/netboot/sh-ip  
	 *  +480h  (4) ---> Kernel (vmlinux:binary) size
	 *  +484h  (4) ---> Boot information size
	 *  +500h  (Boot information size) ---> Boot information
	 */
	buf = (char *)malloc(512);
	if(buf == NULL ){
		printf("add_info: Error was occured at adding data in vmlinux image\n\n
			!!!!!!!!!! CAUTION ==> Build Failed !!!!!!!!!!!!!!!!!!!!!!!\n");
		fclose(f_info);
		fclose(f_kernel);
		exit(1);
	}

	memset(buf, 0, sizeof(buf));
	convert.l = kernel_size;
	buf[0] = convert.b[0];
	buf[1] = convert.b[1];
	buf[2] = convert.b[2];
	buf[3] = convert.b[3];
	
	err = fseek(f_kernel, (unsigned long)(ADDR_XKERNEL_SIZE), SEEK_SET);
	if(err != 0){
		printf("add_info: Error was occured at adding data in vmlinux image\n\n
			!!!!!!!!!! CAUTION ==> Build Failed !!!!!!!!!!!!!!!!!!!!!!!\n");
		fclose(f_info);
		fclose(f_kernel);
		free(buf);
		exit(1);
	}
	
	/* Write size of kernel at ADDR_XKERNEL_SIZE	*/
	err = fwrite(&buf[0], 1, 4, f_kernel);
	if(err != 4){
		printf("add_info: Error was occured at adding data in vmlinux image\n\n
			!!!!!!!!!! CAUTION ==> Build Failed !!!!!!!!!!!!!!!!!!!!!!!\n");
		fclose(f_info);
		fclose(f_kernel);
		free(buf);
		exit(1);
	}
	
	memset(buf, 0, sizeof(buf));
/* 	convert.l = info_size; */
	convert.l = 288;
	buf[0] = convert.b[0];
	buf[1] = convert.b[1];
	buf[2] = convert.b[2];
	buf[3] = convert.b[3];
	
	/* Write size of kernel at ADDR_BOOTINFO_SIZE = ADDR_XKERNEL_SIZE + 4	*/
	err = fwrite(&buf[0], 1, 4, f_kernel);
	if(err != 4){
		printf("add_info: Error was occured at adding data in vmlinux image\n\n
			!!!!!!!!!! CAUTION ==> Build Failed !!!!!!!!!!!!!!!!!!!!!!!\n");
		fclose(f_info);
		fclose(f_kernel);
		free(buf);
		exit(1);
	}


	/* Read boot information from file(vminfo) 	*/
	memset(buf, 0, sizeof(buf));
/* 	err = fread(&buf[0], 1, info_size, f_info); */
	err = fread(&buf[0], 1, 288, f_info);
/* 	if(err != info_size){ */
	if(err != 288){
		printf("add_info: Error was occured at adding data in vmlinux image\n\n
			!!!!!!!!!! CAUTION ==> Build Failed !!!!!!!!!!!!!!!!!!!!!!!\n");
		fclose(f_info);
		fclose(f_kernel);
		free(buf);
		exit(1);
	}



	err = fseek(f_kernel, (unsigned long)(ADDR_BOOTINFO), SEEK_SET);
	if(err != 0){
		printf("add_info: Error was occured at adding data in vmlinux image\n\n
	 		!!!!!!!!!! CAUTION ==> Build Failed !!!!!!!!!!!!!!!!!!!!!!!\n");
		fclose(f_info);
		fclose(f_kernel);
		free(buf);
		exit(1);
	}

	/* Write boot information at ADDR_BOOTINFO	*/
/* 	err = fwrite(&buf[0], 1, info_size, f_kernel); */
	err = fwrite(&buf[0], 1, 288, f_kernel);
/* 	if(err != info_size){ */
	if(err != 288){
		printf("add_info: Error was occured at adding data in vmlinux image\n\n
			!!!!!!!!!! CAUTION ==> Build Failed !!!!!!!!!!!!!!!!!!!!!!!\n");
		fclose(f_info);
		fclose(f_kernel);
		free(buf);
		exit(1);
	}

	fclose(f_info);
	fclose(f_kernel);
	free(buf);
	exit(0);

}
