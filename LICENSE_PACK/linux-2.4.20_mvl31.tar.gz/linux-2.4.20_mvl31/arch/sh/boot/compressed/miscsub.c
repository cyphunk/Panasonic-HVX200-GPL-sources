/*
 * arch/sh/boot/compressed/misc.c
 * 
 * This is a collection of several routines from gzip-1.0.3 
 * adapted for Linux.
 *
 * malloc by Hannu Savolainen 1993 and Matthias Urlichs 1994
 *
 * Adapted for SH by Stuart Menefy, Aug 1999
 *
 * Modified to use standard LinuxSH BIOS by Greg Banks 7Jul2000
 */

#include <linux/config.h>
#include <asm/uaccess.h>


#undef memset
#undef memcpy
#define memzero(s, n)     memset ((s), 0, (n))

/* static void puts(const char *); */ /* sh arch don't use this func. */
  
extern int _text;		/* Defined in vmlinux.lds.S */
extern int _end;

void* memset(void* s, int c, size_t n)
{
	int i;
	char *ss = (char*)s;

	for (i=0;i<n;i++) ss[i] = c;
	return s;
}

void* memcpy(void* __dest, __const void* __src,
			    size_t __n)
{
	int i;
	char *d = (char *)__dest, *s = (char *)__src;

	for (i=0;i<__n;i++) d[i] = s[i];
	return __dest;
}

#define STACK_SIZE (4096)
long user_stack [STACK_SIZE];
long* stack_start = &user_stack[STACK_SIZE];

#define COMMAND_LINE_MAX 256
#ifdef CONFIG_CMDLINE_BOOL
static const char cmdline[] = CONFIG_CMDLINE;
#else /* !CONFIG_CMDLINE_BOOL */
static const char cmdline[] = "";
#endif /* CONFIG_CMDLINE_BOOL */

void decompress_kernel(void)
{
#ifdef CONFIG_CMDLINE_BOOL
	{
	  int cmdsize = sizeof(cmdline);
	  char *command_ptr = (char *)((unsigned long)&_text+0x20000000);

	  command_ptr += 0x100; /* COMMAND_LINE from setup.c */
	  memzero(command_ptr, COMMAND_LINE_MAX);
	  if (cmdsize > COMMAND_LINE_MAX)
		  cmdsize = COMMAND_LINE_MAX-1;
	  memcpy(command_ptr, cmdline, sizeof(cmdline));
	}
#endif /* CONFIG_CMDLINE_BOOL */
}
