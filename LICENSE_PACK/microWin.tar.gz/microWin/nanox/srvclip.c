#include "device.h"

#if DYNAMICREGIONS
#include "srvclip2.c"
#else
#include "srvclip1.c"
#endif
