bin/nano-X -p & bin/nanowm & bin/move; #sleep 10000
