
# Nano-X applications, press <BREAK> key to exit
# PCF loadable compressed font demo
#
#bin/nano-X & bin/nanowm & bin/pcfdemo /usr/lib/X11/fonts/misc/jc7x14.pcf.gz
#bin/nano-X & bin/nanowm & bin/pcfdemo /usr/lib/X11/fonts/misc/7x14.pcf.gz
#bin/nano-X & bin/nanowm & bin/pcfdemo /usr/lib/X11/fonts/100dpi/helvB12.pcf.gz
#bin/nano-X & bin/nanowm & bin/pcfdemo /usr/lib/X11/fonts/misc/vga.pcf.gz
#bin/nano-X & bin/nanowm & bin/pcfdemo /usr/lib/X11/fonts/misc/6x13.pcf.gz
#bin/nano-X & bin/nanowm & bin/pcfdemo /usr/lib/X11/fonts/misc/9x15.pcf.gz
bin/nano-X & bin/nanowm & bin/pcfdemo /usr/lib/X11/fonts/misc/cursor.pcf.gz & bin/pcfdemo /usr/lib/X11/fonts/misc/vga.pcf.gz & bin/pcfdemo /usr/lib/X11/fonts/100dpi/helvB12.pcf.gz
