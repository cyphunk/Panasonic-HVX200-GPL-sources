# kill old mouse driver
gpm -k
# start mouse driver in repeater mode
gpm -R -t ps2
