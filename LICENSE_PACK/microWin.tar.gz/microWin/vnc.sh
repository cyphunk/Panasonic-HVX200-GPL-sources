bin/nano-X & bin/vnc win98:0
